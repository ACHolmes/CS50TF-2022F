'''
Part ?: VSCode tricks

Adding a few bonus tricks in case you like learning keyboard shortcuts. 
If people like these I can share more!

1) Highlighting several lines and hitting TAB indents each line. hitting SHIFT + TAB de-indents the lines

2) Highlighting a word and hitting F2 (Or FN + F2) will rename a variable/function in ALL locations. Try it on this badly named variable:
'''

print(" === PART ? === \n")

this_is_a_bad_variable_name = 0

print(this_is_a_bad_variable_name + 1)

'''
3) Similarly, highlighting a word and hitting CTRL + SHIFT + L will select all occurences of a string.
   Try using it to rename names to something like lab_names :)
'''